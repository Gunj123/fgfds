(function ($) {
    'use strict';

    /*---WOW active js ---- */
    new WOW().init();



})(jQuery);




    /*----------
    Footer Toggle
    ----------*/
    function footerExplanCollapse() {
        $(".footer-top h5").addClass('toggled');
        $('.footer-top .toggled').on('click',function(e){
            e.preventDefault();
            if ($(window).width() < 992) {
                $(this).toggleClass('active');
                $(this).parent().find('ul').toggleClass('active').toggle('slow');
            }
        });
    }

    $(document).ready(function() {
        // footer
        footerExplanCollapse();
    });

    
    // shop page
    $(function () {
        $(".parent .fa.fa-plus").remove();
        $(".parent .toggled").append("<i class='fa fa-plus'></i>");
        $('.parent .toggled').click(function(e) {
            e.preventDefault();
            if (!$(this).parent().hasClass('active')) {
                $('+ ul', $('a.list-group-item.main-item')).slideUp();
                $('a.list-group-item.main-item').removeClass('active');
            }
            $(this).parent().toggleClass('active');
            $('+ ul', $(this).parent()).slideToggle('slow');
            return false;
        });
    });

       /*----------
    Category page click events
    ----------*/
    function clickEventsInCategoryPage() {
        $('.box-category .toggled').on('click',function(e){
            e.preventDefault();
            if ($(window).width() < 992) {
                $(this).toggleClass('active');
                $(this).parent().find('ul.parent').toggleClass('active').slideToggle('slow');
            }
        });

        $('#column-left .box-content .toggled').on('click',function(e){
            e.preventDefault();
            if ($(window).width() < 992) {
                $(this).toggleClass('active');
                if ($(this).parent().find('ul').length != 0) {
                    $(this).parent().find('ul').toggleClass('active').slideToggle('slow');
                } else {
                    $(this).parent().find('.filter_box').toggleClass('active').slideToggle('slow');
                    $(this).parent().find('.block_box').toggleClass('active').slideToggle('slow');
                }
            }
        });

        $('#column-right .box-content .toggled').on('click',function(e){
            e.preventDefault();
            if ($(window).width() < 992) {
                $(this).toggleClass('active');
                if ($(this).parent().find('ul').length != 0) {
                    $(this).parent().find('ul').toggleClass('active').slideToggle('slow');
                } else {
                    $(this).parent().find('.filter_box').toggleClass('active').slideToggle('slow');
                    $(this).parent().find('.block_box').toggleClass('active').slideToggle('slow');
                }
            }
        });
    }   





$(document).ready(function () {
    // navbar 
    $(".currency_name").click(function () {
        $(".currency_list").slideToggle("slow");
    });

    $("#search_icon").click(function(){
        $("#input_group").slideToggle("slow");
    });


    // shop page 
    $(".icon-grid").click(function(){
        $("#product-list").show();
        $("#product_grid").hide();
      });
      $(".icon-list").click(function(){
        $("#product-list").hide();
        $("#product_grid").show();
      });

    clickEventsInCategoryPage();

});






















